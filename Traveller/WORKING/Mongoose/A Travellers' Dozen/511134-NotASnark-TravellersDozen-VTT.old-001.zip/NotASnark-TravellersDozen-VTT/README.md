# A Travellers' Dozen

These files are part of the *A Travellers' Dozen* supplement, which is
produced under the Traveller's Aid Society license and available on
DriveThruRPG.

Copyright Samuel Penn (sam@notasnark.net), 2021

The files in this directory are licensed under a Creative Commons CC0
license. This allows you to use, modify and distribute the files
without restrictions.

https://creativecommons.org/share-your-work/public-domain/cc0/

Portraits were produced using ArtBreeder.

Starship artwork was produced using Blender.

Logos were produced using Inkscape.

For more gaming material, including Traveller, visit:

https://www.notasnark.net/


